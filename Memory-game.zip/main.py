import random
import time

P1 = ''
P2 = ''
Points_P1 = 0
Points_P2 = 0


Cards = ['A','A','B','B','C','C','D','D','Z','Z','V','V','X','X','Y','Y'] 
M = [[0]*4,
     [0]*4,
     [0]*4,
     [0]*4]

MA = [[False]*4,
     [False]*4,
     [False]*4,
     [False]*4]

class color:
    BOLD = '\033[1m'
    END = '\033[0m'
    RED = '\033[91m'
    UNDERLINE = '\033[4m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'

    
line = color.BLUE + "=========================================================================================================" + color.END
I = color.RED + "Incorrect" + color.END
C = color.GREEN + "Correct" + color.END     

def show_board():
    print("\n")
    time.sleep(1)
    print (color.BOLD + '1 2 3 4' + color.END)
    for row in range(4):
        for col in range(4):
            if MA[row][col]:
                print (M[row][col], end=' ')
            else:
                print ('*', end=' ') 
        print (color.BOLD + str(row+1) + color.END)
    print("\n")
            
def start_board():
    random.shuffle(Cards)
    i = 0
    for row in range(4):
        for col in range(4):
            M[row][col] = Cards[i]
            i += 1
    show_board()
    
def players_names():
    global P1, P2
    P1 = input('Player 1: ')
    P2 = input('Player 2: ')
    print(color.BOLD + line + color.END)

def active_board():
    for row in range(4):
        for col in range(4):
            if not MA[row][col]:
                return True
        
    return False
  
def play(Turn):
    global Points_P1
    global Points_P2
    while Turn == P1 and active_board():
        time.sleep(1.5)
        print(color.UNDERLINE + P1 +"s turn"+ color.END,'\n')
        ev1 = False
        ev2 = False
        print('CARD 1: ')
        while ev1 == False:
            row1 = int(input('Row: '))
            col1 = int(input('Column: '))
            ev1 = evaluate1(row1,col1)
        MA [row1-1][col1-1] = True
        show_board()
        print('CARD 2: ')
        while ev2 == False:
            row2 = int(input('Row: '))
            col2 = int(input('Column: '))
            ev2 = evaluate2(row2,col2)
        MA [row2-1][col2-1] = True
        show_board()
        if M[row1-1][col1-1] == M[row2-1][col2-1]:
            print(color.BOLD + C + color.END)
            print(color.BOLD + line + color.END)
            Points_P1 += 1
        else:
            MA [row1-1][col1-1] = False
            MA [row2-1][col2-1] = False
            print(color.BOLD + I + color.END)
            print(color.BOLD + line + color.END)
            show_board()
            Turn = P2
    while Turn == P2 and active_board():
        time.sleep(1.5)
        print(color.UNDERLINE + P2 +"s turn" + color.END, '\n')
        ev1 = False
        ev2 = False
        print('CARD 1: ')
        while ev1 == False:
            row1 = int(input('Row: '))
            col1 = int(input('Column: '))
            ev1 = evaluate1(row1,col1)
        MA[row1-1][col1-1] = True
        show_board()
        print('CARD 2: ')
        while ev2 == False:
            row2 = int(input('Row: '))
            col2 = int(input('Column: '))
            ev2 = evaluate2(row2,col2)
        MA [row2-1][col2-1] = True
        show_board()
        if M[row1-1][col1-1] == M[row2-1][col2-1]:
            print(color.BOLD + C + color.END)
            print(color.BOLD + line + color.END)
            Points_P2 += 1
        else:
            MA [row1-1][col1-1] = False
            MA [row2-1][col2-1] = False
            print(color.BOLD + I + color.END)
            print(color.BOLD + line + color.END)
            show_board()
            Turn = P1
        
def winner():
    print("\n")
    print(P1,"'s points:",Points_P1)
    print(P2,"'s points:",Points_P2)
    if Points_P1 > Points_P2:
        print("\n")
        print(color.UNDERLINE + "Winner:",P1 + color.END)
    elif Points_P1 == Points_P2:
        print("\n")
        print(color.UNDERLINE + "There wasn't a winner, TIE" + color.END)
    else:
        print("\n")
        print(color.UNDERLINE + "Winner: ",P2+ color.END)
        
def evaluate1(row1,col1):
    if row1 < 1 or row1 > 4 or col1 < 1 or col1 > 4:
        print("\n")
        print(color.RED + "Invalid card, select another one" + color.END)
        return False
    elif MA[row1-1][col1-1] == True:
        print("\n")
        print(color.RED + "This card has already been guessed, select another one"+ color.END)
        return False
    else:
        return True
    
def evaluate2(row2,col2):
    if row2 < 1 or row2 > 4 or col2 < 1 or col2 > 4:
        print("\n")
        print(color.RED + "Invalid card, select another one" + color.END)
        return False
    elif MA[row2-1][col2-1] == True:
        print("\n")
        print(color.RED + "This card has already been guessed, select another one"+ color.END)
        return False
    else:
        return True
        
        
def memory_game():
    global Points_P1
    global Points_P2
    global MA
    start = "Y"
    print("\t"*5, color.BOLD + "Alphabet's memory game" + color.END)
    print("\n")
    print(color.BOLD + "Instructions: " + color.END,"This memory game is between 2 players. The first player will choose 2 cards, if both correspond to the same letter he/she has the right to continue playing and obtains a point, if not be so the turn is changed to the other player and so on. The player with the highest score wins.")
    print("\n")
    y = input("Press Y to play: ")
    while y.upper() == start:
        start_board()
        players_names()
        Turn = P1
        while active_board():
          play(Turn)
        print ("\t"*5, color.BOLD + "End of the game" + color.END)
        winner()
        Points_P1 = 0
        Points_P2 = 0
        MA = [[False]*4,
     [False]*4,
     [False]*4,
     [False]*4]
        print("\n")
        y = input("To play again press Y (press any other button to exit): ")
    print("\n")
    print(color.BOLD + "Thanks for playing!!!" + color.END)

memory_game()